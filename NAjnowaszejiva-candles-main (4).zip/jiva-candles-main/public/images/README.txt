Dodaj tutaj swoje obrazy dla JIVA Candles:

Wymagane pliki (zgodnie z kodem):
- jiva-founder.jpg
- jiva-workspace.jpg
- jiva-ritual.jpg
- jiva-morning.jpg
- jiva-evening.jpg
- jiva-winter.jpg
- jiva-giftset.jpg (opcjonalnie)

Możesz skorzystać z darmowych zdjęć, np. z Unsplash,
tak jak sugerowaliśmy w rozmowie.
